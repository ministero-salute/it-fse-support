import json
import os
import gzip
import requests
import pymongo
from pymongo import MongoClient
from bson import json_util
from datetime import datetime

def load_config(config_file='config.json'):
    """Load JSON configuration file"""
    with open(config_file, 'r') as file:
        return json.load(file)

def download_file(url, file_path):
    """Download file from URL"""
    response = requests.get(url)
    with open(file_path, 'wb') as file:
        file.write(response.content)
    print(f"{file_path} downloaded successfully.")

def import_to_mongodb(mongo_uri, database_name, file_path):
    """Import data to MongoDB"""
    client = MongoClient(mongo_uri)
    db = client[database_name]
    
    # Determine collection name from filename
    collection_name = os.path.splitext(os.path.basename(file_path))[0].replace('.json', '')
    collection = db[collection_name]
    
    # Drop existing collection
    collection.drop()
    
    # Check if file is gzip compressed
    if file_path.endswith('.gzip'):
        with gzip.open(file_path, 'rt', encoding='utf-8') as file:
            data = json_util.loads(file.read())
    else:
        with open(file_path, 'r') as file:
            data = json_util.loads(file.read())
    
    collection.insert_many(data)
    print(f"Imported {len(data)} documents to collection {collection_name}")
      
    if collection_name == 'terminology':
        collection.create_index(
            [("system", pymongo.ASCENDING), ("code", pymongo.ASCENDING), ("deleted", pymongo.ASCENDING), ("version", pymongo.ASCENDING)],
            name="system_1_code_1_deleted_1_version_1"
        )
        print(f"Composite index created on 'system, code, deleted, version' in collection {collection_name}")



def main():
    # Load configuration
    config = load_config('config.json')
    
    # Read configuration settings
    mongo_uri = config['mongo_uri']
    database_name = config['database_name']
    collections_name = config['collections_name']
    
    # Base URL for downloading files
    base_url = 'https://github.com/ministero-salute/it-fse-catalogs/raw/main/mongo-dump/'
    
    # Download and import specified JSON files
    for collection_file in collections_name:
        file_url = base_url + collection_file
        file_path = collection_file  # Save in the same directory as the script
        
        print(f"Importing file {collection_file} from {file_url}...")
        download_file(file_url, file_path)
        import_to_mongodb(mongo_uri, database_name, file_path)

if __name__ == '__main__':
    main()