# MongoDB JSON Importer

Questo script Python importa nel proprio database MongoDB i mongo dump messi a disposizione alla seguente URL: https://github.com/ministero-salute/it-fse-catalogs/raw/main/mongo-dump/ .Puoi facilmente configurare l'URI di MongoDB, il nome del database e i file JSON da importare attraverso il file config.json.

## Requisiti

Per eseguire questo script, è necessario avere:
- **Python 3.6+** installato
- **MongoDB** (locale o remoto)
- Un ambiente virtuale Python (opzionale ma consigliato)
- Le librerie Python necessarie (verranno installate tramite `requirements.txt`)

## Installazione

1. Creare e attivare un ambiente virtuale (opzionale):  
 
    - Su macOS/Linux:
    ```bash
        python3 -m venv venv
        source venv/bin/activate
    ```
    
    - Su Windows:
    ```bash
        python -m venv venv
        venv\Scripts\activate
    ```
3. Installare le dipendenze tramite `requirements.txt`:
    ```bash
    pip install -r requirements.txt        
    ```

4. Configurare il file config.json:    
    ```json
    {
        "mongo_uri": "mongodb://localhost:27888",
        "database_name": "FSE_GTW",
        "collections_name": [
            "dictionary.json",
            "schema.json",
            "schematron.json",
            "terminology.json",
            "transform.json",
            "config_data.json"
        ]
    }
    ```
5. Eseguire lo script:    
    ```bash
    python nome_script.py
    ```